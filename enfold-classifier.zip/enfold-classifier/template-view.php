<?php if (!defined('ABSPATH')) exit; ?>

<!-- 1. Fonts & Libraries -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Amaranth:ital,wght@0,400;0,700;1,400;1,700&family=Jost:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Neuton:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<!-- 2. Scoped Styling -->
<style>
  :root{
    --ink:#171B22;
    --navy:#212E3D;
    --navy-2:#2B3B4E;
    --paper:#FBF8F2;
    --paper-dim:#F1ECE0;
    --rule:#DCD4BE;
    --muted:#6B6459;
    --muted-2:#8B93A1;
    --crimson:#8B2E2E;
    --crimson-bg:#F7E9E7;
    --forest:#3C6E47;
    --forest-bg:#E9F1E9;
    --amber:#9C6B1E;
    --amber-bg:#F6EDDB;
    --gray-bg:#ECE9E2;
    --shadow: 0 1px 3px rgba(23,27,34,0.08), 0 1px 2px rgba(23,27,34,0.06);
    --shadow-lg: 0 8px 24px rgba(23,27,34,0.16);
  }
  #enfold-classifier-container * { box-sizing:border-box; }
  #enfold-classifier-container {
    background:#f4ead5;
    color:var(--ink);
    font-family:'Jost', -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
    font-weight:400;
    padding: 20px 10px 40px;
    border-radius: 8px;
  }
  #enfold-classifier-container h1, 
  #enfold-classifier-container h2, 
  #enfold-classifier-container h3, 
  #enfold-classifier-container .card h2, 
  #enfold-classifier-container .modal h3 {
    font-family:'Amaranth', Georgia, serif;
    font-weight:700;
  }
  .serif{ font-family: 'Neuton', Georgia, serif; font-weight:400; }
  .mono{ font-family: 'SF Mono', ui-monospace, Menlo, Consolas, monospace; }

  .app{ max-width: 1100px; margin: 0 auto; padding: 0 10px 40px; }

  header.top{
    padding: 20px 10px 0;
    max-width: 1100px;
    margin: 0 auto;
    color: var(--ink);
    display:flex;
    align-items:flex-start;
    justify-content:space-between;
    gap:24px;
  }
  header.top .header-text{ flex:1; min-width:0; }
  header.top .header-logo{
    flex:0 0 auto;
    width:96px;
    height:96px;
    background:#fff;
    border-radius:12px;
    padding:10px;
    box-shadow: var(--shadow-lg);
  }
  header.top .header-logo img{ width:100%; height:100%; object-fit:contain; display:block; }
  header.top .eyebrow{
    font-size:11px; letter-spacing:.14em; text-transform:uppercase; color:#F59120;
    font-weight:600; margin-bottom:8px;
  }
  header.top h1{
    font-size: 28px; margin:0 0 6px; font-weight:600; letter-spacing:-0.01em;
    color:#8F288C;
  }
  header.top p.sub{
    margin:0 0 24px; color:var(--muted); font-size:14.5px; max-width:640px; line-height:1.5;
  }

  main.panel{
    background: var(--paper);
    border-radius: 10px;
    box-shadow: var(--shadow-lg);
    padding: 28px;
    min-height: 420px;
  }
  .tabpage{ display:none; }
  .tabpage.active{ display:block; }

  .card{
    background:#fff;
    border:1px solid var(--rule);
    border-radius:10px;
    padding:20px;
    margin-bottom:20px;
  }
  .card h2{ margin:0 0 4px; font-size:17px; color:#8F288C; }
  .card .hint{ color:var(--muted); font-size:13px; margin:0 0 16px; }

  .form-row{ display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end; }
  .form-row + .form-row{ margin-top:14px; }
  .field{ display:flex; flex-direction:column; gap:6px; flex:1; min-width:160px; }
  .field label{ font-size:12px; font-weight:600; color:var(--muted); text-transform:uppercase; letter-spacing:.04em; }
  select, input[type=text], input[type=search], textarea{
    font-family:inherit;
    font-size:14px;
    padding:9px 10px;
    border:1px solid #CFC7B0;
    border-radius:7px;
    background:#fff;
    color:var(--ink);
  }
  textarea{ resize:vertical; min-height:60px; line-height:1.4; }
  select:focus, input:focus, textarea:focus, button:focus-visible{
    outline: 2px solid #C9A24A; outline-offset:1px;
  }

  .combo{ position:relative; flex:2; min-width:220px; }
  .combo-list{
    position:absolute; top:100%; left:0; right:0; margin-top:4px;
    background:#fff; border:1px solid var(--rule); border-radius:8px;
    box-shadow: var(--shadow-lg);
    max-height:280px; overflow-y:auto; z-index:20; display:none;
  }
  .combo-list.open{ display:block; }
  .combo-item{ padding:9px 12px; cursor:pointer; border-bottom:1px solid var(--paper-dim); }
  .combo-item:last-child{ border-bottom:none; }
  .combo-item:hover, .combo-item.hi{ background: var(--paper-dim); }
  .combo-item .lbl{ font-weight:700; font-family:'SF Mono',ui-monospace,monospace; font-size:13px; }
  .combo-item .prev{ color:var(--muted); font-size:12px; margin-top:2px; display:block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .combo-empty{ padding:14px 12px; color:var(--muted); font-size:13px; }

  .btn{
    appearance:none; cursor:pointer; border-radius:7px; font-family:inherit;
    font-weight:600; font-size:13.5px; padding:10px 16px; border:1px solid transparent;
  }
  .btn-primary{ background:var(--navy); color:#fff; }
  .btn-primary:hover{ background:var(--navy-2); }
  .btn-primary:disabled{ background:#B9BEC6; cursor:not-allowed; }
  .btn-ghost{ background:transparent; color:var(--navy); border-color:#C9C1A8; }
  .btn-ghost:hover{ background:var(--paper-dim); }
  .btn-danger{ background:transparent; color:var(--crimson); border-color:#E0BEBE; }
  .btn-danger:hover{ background:var(--crimson-bg); }
  .btn-sm{ padding:6px 10px; font-size:12.5px; border-radius:6px; }

  /* Verdict stamp */
  .verdict{
    display:flex; align-items:center; gap:22px; padding:22px 24px; border-radius:12px;
    margin-bottom:22px; border:1px solid var(--rule);
  }
  .verdict.empty{ color:var(--muted); font-size:14px; background:var(--paper-dim); border-style:dashed; }
  .stamp{
    font-family: Georgia, serif;
    font-weight:700; font-size:20px; letter-spacing:.06em; text-transform:uppercase;
    border:3px solid currentColor; border-radius:8px; padding:10px 18px;
    transform: rotate(-4deg);
    white-space:nowrap;
  }
  .verdict.heinous{ background:var(--crimson-bg); }
  .verdict.heinous .stamp{ color:var(--crimson); }
  .verdict.not_heinous{ background:var(--forest-bg); }
  .verdict.not_heinous .stamp{ color:var(--forest); }
  .verdict.review{ background:var(--amber-bg); }
  .verdict.review .stamp{ color:var(--amber); }
  .verdict .vtext{ font-size:13.5px; color:var(--ink); line-height:1.5; }
  .verdict .vtext strong{ display:block; font-size:15px; margin-bottom:3px; }
  .verdict .counts{ margin-left:auto; display:flex; gap:16px; font-size:12.5px; color:var(--muted); text-align:center; }
  .verdict .counts div b{ display:block; font-size:18px; color:var(--ink); }

  table.list{ width:100%; border-collapse:collapse; font-size:13.5px; }
  table.list th{
    text-align:left; font-size:11px; text-transform:uppercase; letter-spacing:.05em;
    color:var(--muted); border-bottom:1px solid var(--rule); padding:8px 10px; font-weight:600;
  }
  table.list td{ padding:10px; border-bottom:1px solid var(--paper-dim); vertical-align:top; }
  table.list tr:last-child td{ border-bottom:none; }
  .badge{
    display:inline-block; padding:3px 9px; border-radius:99px; font-size:11.5px; font-weight:700;
    text-transform:uppercase; letter-spacing:.03em;
  }
  .badge.heinous{ background:var(--crimson-bg); color:var(--crimson); }
  .badge.not_heinous{ background:var(--forest-bg); color:var(--forest); }
  .badge.depends{ background:var(--amber-bg); color:var(--amber); }
  .badge.unknown{ background:var(--gray-bg); color:var(--muted); }

  .sec-cell .stat{ font-family:'SF Mono',ui-monospace,monospace; font-weight:700; }
  .sec-cell .act{ color:var(--muted); font-size:11.5px; display:block; margin-top:2px; }
  .expand-btn{ background:none; border:none; color:var(--navy); cursor:pointer; font-size:12px; padding:0; text-decoration:underline; font-family:inherit; }
  .fulltext-row td{ background:var(--paper-dim); font-size:12.5px; line-height:1.55; white-space:pre-wrap; color:var(--ink); }
  .rowremove{ background:none; border:none; color:#B0463F; cursor:pointer; font-size:16px; line-height:1; padding:2px 6px; }

  .empty-state{ text-align:center; padding:40px 20px; color:var(--muted); font-size:14px; }
  .note-box{
    background:var(--amber-bg); border:1px solid #E4CE9C; color:#6B4E14;
    border-radius:8px; padding:12px 16px; font-size:13.5px; margin-bottom:16px; line-height:1.5;
  }

  footer.appfoot{ text-align:center; color:#8891A0; font-size:12px; margin-top:22px; line-height:1.6; }
  footer.appfoot a{ color:#C9A24A; }
</style>

<!-- 3. Main HTML Content -->
<header class="top">
  <div class="header-text">
    <div class="eyebrow">Juvenile Justice Act, 2015 · Section 2(32) &amp; 2(54)</div>
    <h1>Check whether an offence is Heinous under the Juvenile Justice Act, 2015</h1>
    <p class="sub">Enter every section a child in conflict with law (CICL) has been charged with to see whether the offence is heinous, not heinous, or depends on other charges/facts.</p>
  </div>
</header>

<div class="app">
<main class="panel">
  <section id="tabpage-check" class="tabpage active">
    <div class="card no-print">
      <h2>Add an offence</h2>
      <p class="hint">Choose the statute, then find the section. If that section has sub-clauses with different classifications, you'll be asked to pick the exact one.</p>
      <div class="form-row">
        <div class="field" style="flex:1;min-width:180px;">
          <label for="sel-statute">Statute</label>
          <select id="sel-statute" onchange="onStatuteChange()"></select>
        </div>
        <div class="field combo" style="flex:2;min-width:220px;">
          <label for="inp-section">Section</label>
          <input type="text" id="inp-section" placeholder="Search section number…" autocomplete="off" oninput="onSectionSearch()" onfocus="onSectionSearch()">
          <div class="combo-list" id="section-combo-list"></div>
        </div>
        <div class="field" id="subclause-field" style="flex:1;min-width:180px;display:none;">
          <label for="sel-subclause">Sub-clause</label>
          <select id="sel-subclause" onchange="onSubclauseChange()"></select>
        </div>
        <div class="field" style="flex:0 0 auto;">
          <button class="btn btn-primary" id="btn-add-offence" onclick="addOffenceToCase()" disabled>Add to case</button>
        </div>
      </div>
    </div>

    <div class="note-box">Preliminary assessment should only be done in heinous offences.</div>

    <div class="card" id="case-list-card">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
        <h2 style="margin-bottom:0;">Offences in this case</h2>
        <div class="no-print" style="display:flex;gap:8px;">
          <button class="btn btn-ghost btn-sm" onclick="window.print()">Print summary</button>
          <button class="btn btn-danger btn-sm" onclick="clearCase()">Clear all</button>
        </div>
      </div>
      <div id="case-table-wrap"></div>
    </div>
  </section>
</main>

<div class="card" id="info-card" style="max-width:1100px;margin:24px auto 0;">
  <h2 class="serif" style="font-size:19px;">Why does it matter whether the offence is heinous or not as per the Juvenile Justice Act (JJ Act), 2015?</h2>
  <p>Identifying whether an offence is Heinous or not under the definition of offences under the JJ Act, 2015 is important, particularly in the context of &mdash;</p>
  <ol style="padding-left:20px;line-height:1.6;">
    <li>Preliminary assessment under section 15, JJ Act, 2015 for children between the ages of 16&ndash;18 who have allegedly committed heinous offences.</li>
    <li>At the time of the FIR, Rule 8, JJ Model Rules, 2016, directs the police to file an FIR for Heinous offences. In other offences, a general diary complaint can be filed.</li>
    <li>The power to apprehend shall only be exercised with regard to heinous offences, unless it is in the best interest of the child.</li>
  </ol>
  <p><strong>Definition of Heinous offence.</strong><br>
  Section 2(32), JJ Act, 2015 &mdash; &ldquo;heinous offences&rdquo; includes the offences for which the minimum punishment under the Indian Penal Code or any other law for the time being in force is imprisonment for seven years or more.</p>
  <p>This tool also takes into consideration the 2021 Amendment of the JJ Act, 2015, which clarified that if an offence has no minimum punishment or a minimum punishment of less than 7 years, it will be a serious offence and will not be heinous. (Section 2(54), JJ Act, 2015)</p>
  <p>Please reach out to us with suggestions and improvements at <a href="mailto:research@enfoldindia.org">research@enfoldindia.org</a>.</p>
</div>

<footer class="appfoot">
  This tool is a reference aid and does not substitute independent legal verification of the applicable statute and its latest amendments.
</footer>
</div>

<!-- 4. Interactive Logic -->
<script>
let offencesDb = [];
let currentCase = [];
let activeStatute = "";
let selectedOffence = null;

// Read dynamic data from WordPress JSON tag
function initClassifierApp() {
  const seedEl = document.getElementById('seed-data');
  if (seedEl && seedEl.textContent.trim()) {
    try {
      offencesDb = JSON.parse(seedEl.textContent);
    } catch(e) {
      offencesDb = [];
    }
  }

  initStatuteDropdown();
  renderCaseTable();
}

function initStatuteDropdown() {
  const statuteSelect = document.getElementById('sel-statute');
  if (!statuteSelect) return;
  
  const statutes = [...new Set(offencesDb.map(item => item.statute))].filter(Boolean).sort();
  statuteSelect.innerHTML = '<option value="">-- Choose Statute --</option>';
  statutes.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s;
    opt.textContent = s;
    statuteSelect.appendChild(opt);
  });
}

function onStatuteChange() {
  activeStatute = document.getElementById('sel-statute').value;
  document.getElementById('inp-section').value = '';
  document.getElementById('subclause-field').style.display = 'none';
  document.getElementById('btn-add-offence').disabled = true;
  selectedOffence = null;
}

function onSectionSearch() {
  const query = document.getElementById('inp-section').value.trim().toLowerCase();
  const combo = document.getElementById('section-combo-list');
  combo.innerHTML = '';
  
  if (!activeStatute || !query) {
    combo.classList.remove('open');
    return;
  }

  const matches = offencesDb.filter(o => o.statute === activeStatute && o.section.toLowerCase().includes(query));
  
  // Group by unique section numbers
  const uniqueSecs = [...new Set(matches.map(m => m.section))];

  if (uniqueSecs.length === 0) {
    combo.innerHTML = '<div class="combo-empty">No matching section found</div>';
  } else {
    uniqueSecs.forEach(sec => {
      const item = document.createElement('div');
      item.className = 'combo-item';
      item.innerHTML = `<span class="lbl">Section ${sec}</span>`;
      item.onclick = () => selectSection(sec);
      combo.appendChild(item);
    });
  }
  combo.classList.add('open');
}

function selectSection(sec) {
  document.getElementById('inp-section').value = sec;
  document.getElementById('section-combo-list').classList.remove('open');
  
  const subclauses = offencesDb.filter(o => o.statute === activeStatute && o.section === sec);
  
  if (subclauses.length === 1 && !subclauses[0].subclause) {
    document.getElementById('subclause-field').style.display = 'none';
    selectedOffence = subclauses[0];
    document.getElementById('btn-add-offence').disabled = false;
  } else {
    const subSelect = document.getElementById('sel-subclause');
    subSelect.innerHTML = '<option value="">-- Choose Sub-clause --</option>';
    subclauses.forEach((sc, i) => {
      const opt = document.createElement('option');
      opt.value = sc.id;
      opt.textContent = sc.label + ' (' + sc.heinousStatus.replace('_', ' ') + ')';
      subSelect.appendChild(opt);
    });
    document.getElementById('subclause-field').style.display = 'flex';
    document.getElementById('btn-add-offence').disabled = true;
  }
}

function onSubclauseChange() {
  const val = document.getElementById('sel-subclause').value;
  selectedOffence = offencesDb.find(o => o.id === val);
  document.getElementById('btn-add-offence').disabled = !selectedOffence;
}

function addOffenceToCase() {
  if (selectedOffence && !currentCase.some(item => item.id === selectedOffence.id)) {
    currentCase.push(selectedOffence);
    renderCaseTable();
  }
}

function removeOffence(id) {
  currentCase = currentCase.filter(item => item.id !== id);
  renderCaseTable();
}

function clearCase() {
  currentCase = [];
  renderCaseTable();
}

function renderCaseTable() {
  const wrap = document.getElementById('case-table-wrap');
  if (currentCase.length === 0) {
    wrap.innerHTML = '<div class="empty-state">No charges added yet. Select a section above to assess.</div>';
    return;
  }

  let html = `<table class="list">
    <thead>
      <tr>
        <th>Statute & Section</th>
        <th>Minimum Punishment</th>
        <th>Classification</th>
        <th></th>
      </tr>
    </thead>
    <tbody>`;

  currentCase.forEach(item => {
    const badgeClass = item.heinousStatus;
    const badgeText = item.heinousStatus.replace('_', ' ');

    html += `<tr>
      <td class="sec-cell">
        <span class="stat">${item.label}</span>
        <span class="act">${item.statute}</span>
      </td>
      <td>${item.minPunishment || 'None'}</td>
      <td><span class="badge ${badgeClass}">${badgeText}</span></td>
      <td style="text-align:right;"><button class="rowremove" onclick="removeOffence('${item.id}')">&times;</button></td>
    </tr>`;
  });

  html += '</tbody></table>';
  wrap.innerHTML = html;
}

// Close search dropdown on clicking outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('.combo')) {
    const combo = document.getElementById('section-combo-list');
    if (combo) combo.classList.remove('open');
  }
});

document.addEventListener('DOMContentLoaded', initClassifierApp);
</script>